library(testthat)
require(neuralnetwork)
test_check("neuralnetwork")